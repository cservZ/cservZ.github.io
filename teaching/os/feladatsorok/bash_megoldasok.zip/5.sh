#!/bin/bash

: '
	5. Írj BASH szkriptet 5.sh néven, amely két olyan szöveges fájlt kap paraméterül, 
	amelynek minden sora egy-egy szót tartalmaz (az egyik fájlban angol, a másikban 
	magyar szavak szerepelnek). Ha a két fájl ugyanannyi sorból áll, akkor fésüld össze 
	azok sorait pontosvesszők mentén egy dictionary.txt fájlba a példában látható módon! 
	Egyéb esetben (ha a két fájl nem ugyanannyi sorból áll), írass ki hibaüzenetet!
'

# Eltároljuk egy-egy változóban az 1. és 2. paraméterben érkező fájlok sorainak számát

sorok_szama1=`cat $1 | wc -l`
sorok_szama2=`cat $2 | wc -l`

# Ha a két fájl nem ugyanannyi sorból áll, akkor hibaüzenetet íratunk ki,
# egyébként pedig összefésüljük a fájlok tartalmát pontosvesszők mentén

if [[ $sorok_szama1 -ne $sorok_szama2 ]]; then
	echo "HIBA: A ket fajl nem ugyanannyi sorbol all!"
else
	# Egy fontos probléma, hogy mivel a későbbiekben a dictionary.txt fájl meglévő tartalmához fűzünk hozzá,
	# ezért a szkript újbóli lefuttatása során a korábbi futtatás eredménye a fájlban marad. Egy lehetséges
	# megoldása ennek a problémának, hogy ha már létezik a dictionary.txt, akkor töröljük
	
	if [[ -e dictionary.txt ]]; then
		rm dictionary.txt
	fi

	# Ebben a változóban fogjuk letárolni, hogy éppen hanyadik sorban vagyunk (kezdetben az első sorban)
	count=1
	
	# Bejárjuk az 1. paraméterben kapott fájl sorait egy for-ciklussal
	# Ez a ciklus valójában a sorokban található szavakat járja be, így ha egy sor több szót is
	# tartalmazna, akkor nem jól működne, de mivel a feladat szövege garantálta, hogy minden sorban 
	# egy szó van, ezért ez nem probléma, ezzel az esettel a gyakorlaton nem foglalkozunk
	
	for sor1 in `cat $1`; do
		# Lekérjük a 2. paraméterben kapott fájlból az annyiadik sorszámú sort, mint ahanyadik sort épp bejárjuk
		sor2=`head -$count $2 | tail -1`
		
		# A két fájl megfelelő sorát pontosvesszővel elválasztva összefésüljük, és hozzáfűzzük a dictionary.txt tartalmához
		echo "$sor1;$sor2" >> dictionary.txt
		
		# Minden meglátogatott sor után megnöveljük a "hányadik sorban vagyunk épp" változónk értékét
		count=$(($count+1))
	done
fi
