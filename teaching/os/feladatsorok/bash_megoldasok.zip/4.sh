#!/bin/bash

: '
	4. Írj BASH szkriptet 4.sh néven, amely összeszorozza a paraméterben kapott
	könyvtárban található txt fájlok szavainak számát, és kiírja az így kapott szorzatot 
	a konzolra! Amennyiben nem egy könyvtár elérési útvonala érkezik paraméterben, akkor 
	írass ki hibaüzenetet és a program lépjen ki 10-es hibakóddal!
'

# Ha nem egy könyvtárat kapunk paraméterül, akkor hibaüzenetet íratunk ki és 10-es hibakóddal kilépünk
# Rögtön a szkript lefuttatása után kiírathatjuk a kilépési kódot terminálban a következő paranccsal: echo $?

if [[ ! -d $1 ]]; then
	echo "HIBA: Nem konyvtar!"
	exit 10
fi

# Miután meggyőződtünk arról, hogy az 1. paraméter egy könyvtár, belelépünk (ez nem kötelező)
cd $1

# Létrehozunk egy változót a szorzatnak, ami kezdetben 1 (nem 0, mert akkor mindig 0 maradna, bármivel is szorozzuk)
szorzat=1

# Bejárjuk az aktuális mappa txt kiterjesztésű fájljait
# (Az aktuális mappa az 1. paraméterben kapott mappa, mert korábban cd-vel beleléptünk)

for fajl in `ls *.txt`; do
	# Megszámoljuk az aktuális fájlban található szavak számát, és ezt eltároljuk egy változóban
	szavak_szama=`cat $fajl | wc -w`
	
	# Megszorozzuk az szorzat változónk eddigi értékét a fájlban található szavak számával
	szorzat=$(($szorzat*$szavak_szama))
done

# Végül kiírjuk a kiszámolt szorzat értékét a konzolra
echo $szorzat
