#!/bin/bash
 
: '
	6. Készíts egy egyszerű számkitalálós játékot egy 6.sh nevű BASH fájlba! 
	A gép "gondol" egy számra 1 és 1000 között (az 1 és az 1000 is még beletartozik 
	a lehetséges számok intervallumába), és a felhasználó ezt a számot próbálja meg 
	minél kevesebb próbálkozással kitalálni. A felhasználónak a játék elején 20 élete 
	(próbálkozási lehetősége) van.
'

# Változó a gép által gondolt számnak (1 és 1000 közötti randomszámot generálunk)
gondolt_szam=$((1 + $RANDOM % 1000))

# Változó a felhasználó életeinek (tippelési lehetőségeinek)
eletek_szama=20

# Egy végtelen ciklus (ebből majd akkor lépünk ki, ha a játék véget ér)

while true; do
	# A felhasználó tippjének bekérése a konzolról
	
	echo -n "Tipp: "					# -n kapcsoló: nem tesz sortörést a kiíratás után
	read tipp 							# a felhasználó tippjét egy tipp nevű változóba olvassuk be
	
	# Ha a felhasználó nem találja el a gondolt számot, kiírjuk, hogy a gondolt szám kisebb vagy nagyobb a felhasználó tippjénél
	
	if [[ $tipp -ne $gondolt_szam ]]; then
		if [[ $gondolt_szam -lt $tipp ]]; then
			echo "Kisebb"
		else
			echo "Nagyobb"
		fi
		
		eletek_szama=$(($eletek_szama-1))	# hibás tipp esetén csökkentjük a megmaradt életek számát 1-gyel
	fi
	
	# Ha a felhasználó kitalálja a gondolt számot, akkor a játéknak vége és a felhasználó nyer
	
	if [[ $tipp -eq $gondolt_szam ]]; then
		echo "-------------------------------------------------"
		echo "Gratulalok, nyertel!"
		echo "A gondolt szam valoban $gondolt_szam volt."
		echo "Megmaradt eletek: $eletek_szama."
		break							# vége a játéknak, kilépünk a ciklusból
	fi
	
	# Ha az életek elfogytak, akkor a játéknak vége és a felhasználó veszít
	
	if [[ $eletek_szama -eq 0 ]]; then
		echo "-------------------------------------------------"
		echo "Sajnos nem nyertel!"
		echo "A gondolt szam $gondolt_szam volt."
		break							# vége a játéknak, kilépünk a ciklusból
	fi
done
