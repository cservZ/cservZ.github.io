#!/bin/bash

: '
	1. Írj BASH szkriptet 1.sh néven, amely a paraméterben kapott fájlban 
	megkeresi azokat a sorokat, amelyek tartalmazzák a macska szöveget, 
	és kiíratja ezeket csupa nagybetűsen egy result.txt nevű állományba! 
	Hibakezeléssel nem kell foglalkoznod.
'

# Először kiválogatjuk az 1. paraméterben megkapott fájlból azokat a sorokat, amelyek tartalmazzák a "macska" szöveget
# egrep "macska" $1

# Az előző parancs kimenetét csupa nagybetűssé alakítjuk (a parancsok között a szokásos pipeline szerepel)
# egrep "macska" $1 | tr a-z A-Z

# Végül az így kapott eredményt beleírjuk egy result.txt nevű fájlba
egrep "macska" $1 | tr a-z A-Z > result.txt
