#!/bin/bash

: '
	3. Írj BASH szkriptet 3.sh néven, amely kiírja, hogy a paraméterben kapott 
	számok közül mennyi páros, illetve mennyi páratlan! Hibakezeléssel nem kell 
	foglalkoznod, feltesszük, hogy a szkript paraméterezése helyes.
'

# Számláló változók létrehozása a páros és páratlan paraméterek darabszámának eltárolására
# Az értékadáskor az egyenlőségjel előtt és után nem szerepelhet szóköz BASH-ben, különben hibát kapunk! ¯\_(ツ)_/¯

paros_db=0
paratlan_db=0

# Egy for-ciklussal végigmegyünk a szkript parancssori paraméterein
# A $* visszaadja a paramétereket szóközzel elválasztva egy stringben, ezt járjuk be lényegében

for szam in $*; do
	# Annak függvényében, hogy az aktuális paraméter páros-e vagy sem, megnöveljük a megfelelő számláló változó értékét
	# A paritásellenőrzés a szokásos: ha egy szám 2-vel osztva 0-t ad maradékul, akkor páros, egyébként páratlan (progalap goes brr)
	# ------------------------------------------------------------------------------------------------------------------------------
	# A $(( )) azért kell, hogy kiértékeljük a matematikai kifejezést, és az EREDMÉNYT adjuk értékül a megfelelő változónak
	# Természetesen $(( )) helyett használhattuk volna például a let-et is, vagy az `expr` parancsot

	if [[ $(($szam%2)) -eq 0 ]]; then
		paros_db=$(($paros_db+1))
	else
		paratlan_db=$(($paratlan_db+1))
	fi
done

# Kiíratjuk a kiszámolt értékeket egy kis fancy szöveges körítéssel
# Fontos, hogy idézőjeleket használjunk, amikor változók értékeit szeretnénk behelyettesíteni egy szövegben!

echo "$paros_db darab paros, $paratlan_db darab paratlan szamot kaptam parameterben."
