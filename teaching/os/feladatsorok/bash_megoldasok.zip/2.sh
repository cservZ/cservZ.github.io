#!/bin/bash

: '
	2. Írj BASH szkriptet 2.sh néven, amely két paramétert kap: rendre egy szöveget 
	és egy számot! Ha a szám 1-nél kisebb, akkor írasd ki a Hiba szöveget a konzolra! 
	Ellenkező esetben a szkript írja ki annyiszor az első paraméterben érkező szöveget, 
	mint amennyi a második paraméterben kapott szám!
'

if [[ $2 -lt 1 ]]; then
	# Ha a második paraméterben kapott szám 1-nél kisebb, akkor hibaüzenetet íratunk ki
	# Számok összehasonlításakor célszerű a Lékó Gábor honlapján megtalálható speciális kapcsolókat használni
	
	echo "Hiba"
else
	# Egyébként kiírjuk az 1. paraméterben érkező szöveget annyiszor, mint amennyi a 2. paraméterben kapott szám
	# Ezt most egy for-ciklussal oldjuk meg, ami annyiszor fog lefutni, mint amennyi a 2. paraméter ($2), és
	# a cikluson belül minden iterációban kiíratjuk az 1. paraméterben kapott értéket ($1)
	
	for (( i=0; i<$2; i++ )); do
		echo $1
	done
fi
