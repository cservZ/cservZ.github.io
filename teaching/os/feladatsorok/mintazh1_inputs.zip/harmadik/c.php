<?php
	echo "Szereted a kutyakat? Ha igen, akkor itt van 101 kiskutya. <br/><br/>";
	
	for ($i = 1; $i <= 101; $i++) {
		echo "$i. kiskutya <br/>";
	}
?>
