<?php
    $array = ["give you up", "let you down", "run around"];
    foreach ($array as $item) {
        echo "Never gonna $item <br/>";
    }
    echo "And desert you <br/>";
