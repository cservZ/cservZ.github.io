#!/bin/bash

: '
	7. Írj BASH szkriptet 7.sh néven, amely egy könyvtár elérési útvonalát várja paraméterben! 
	A szkript írja ki a konzolra a paraméterben kapott könyvtárban található, legtöbb sorból álló php
	kiterjesztésű fájlnak a nevét! Ha több fájl is ugyanannyi sorból áll, akkor közülük az ábécé 
	sorrendben hamarabb szereplő fájlnevet válaszd!
'

# Mivel a feladat nem kérte, hogy kezeljük le azt az esetet, amikor a paraméter nem egy mappa, ezért
# feltesszük, hogy paraméterben ténylegesen egy mappát kapunk. Ekkor bele is léphetünk ebbe a mappába.

cd $1

# A feladat megoldásához két változóra lesz szükségünk.

legtobb_sor=-1              # Ez a változó fogja tárolni, hogy hány sorból áll a legtöbb sorból álló fájl.
leghosszabb_fajl=""         # Ez a változó fogja tárolni a legtöbb sorból álló fájl nevét.

# Bejárjuk a mappában található php-fájlokat. Mivel azonos hosszúságú fájlok esetén az ábécé sorrendben
# hamarabb szereplő fájl nevét kell választanunk, ezért használhatjuk a `sort` parancsot is, viszont ez
# igazából fölösleges, mert az `ls` alapból ábécé sorrendben listázza ki a mappa tartalmát.

for fajl in `ls *.php | sort`; do
	# Eltároljuk egy változóban, hogy az aktuális fájl hány sorból áll.
	sorok_szama=`cat $fajl | wc -l`
	
	# Ha az aktuális fájl több sorból áll, mint a leghosszabb fájl, akkor frissítjük a két változónk
	# értékét ennek megfelelően.
	
	if [[ $sorok_szama -gt $legtobb_sor ]]; then
		legtobb_sor=$sorok_szama
		leghosszabb_fajl=$fajl
	fi
done

# A program végén kiíratjuk a konzolra a legtöbb sorból álló PHP fájl nevét.
echo $leghosszabb_fajl
