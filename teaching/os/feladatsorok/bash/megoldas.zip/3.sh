#!/bin/bash

: '
	3. Írj BASH szkriptet 3.sh néven, amely két paramétert vár: rendre egy fájl elérési útvonalát 
	és egy stringet! A szkript válogassa ki az első paraméterben kapott fájlnak azon sorait, 
	amelyek bármilyen formában (a kis- és nagybetűket nem megkülönböztetve, akár részstringként is) 
	tartalmazzák a második paraméterben kapott stringet! Ezeket a sorokat a program írja bele egy 
	result.dat nevű állományba!
'

# Az `egrep` paranccsal kiválogatjuk az 1. paraméterben kapott fájlból ($1) azokat a sorokat, amelyek
# tartalmazzák a 2. paraméterben kapott szöveget ($2). A `man egrep` vagy `egrep --help` paranccsal
# megtudhatjuk, hogy van az `egrep`-nek egy -i ("ignore case") kapcsolója, amivel figyelmen kívül
# hagyhatjuk a kis- és nagybetűk közötti különbséget.

# egrep -i $2 $1

# Az előzőekben megalkotott parancs kimenetét beleirányítjuk egy result.dat nevű fájlba.
egrep -i $2 $1 > result.dat
