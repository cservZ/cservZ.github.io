#!/bin/bash

: '
	1. Írj BASH szkriptet 1.sh néven, amely két paramétert kap: rendre egy szót és egy számot!
	Ha a szám 1-nél kisebb, akkor írasd ki a "HIBA!" szöveget a konzolra! Ellenkező esetben írasd 
	ki az első paraméterben kapott szót annyiszor, mint amennyi a második paraméterben kapott szám!
'

if [[ $2 -lt 1 ]]; then
	# Ha a 2. paraméterben kapott szám 1-nél kisebb, akkor hibaüzenetet íratunk ki.
	# Számok összehasonlításakor célszerű a Lékó Gábor honlapján szereplő speciális kapcsolókat használni.
	
	echo "HIBA!"
else
	# Ellenkező esetben kiírjuk az 1. paraméterben kapott szót annyiszor, mint amennyi a 2. paraméterben
	# kapott szám. Ezt most egy for-ciklussal oldjuk meg, ami annyiszor fog lefutni, mint amennyi a 2.
	# paraméter értéke ($2), és a cikluson belül minden iterációban kiíratjuk az 1. paraméterben
	# kapott értéket ($1). Természetesen ezt while-ciklussal vagy do-until ciklussal is megoldhattuk volna.
	
	for (( i=0; i<$2; i++ )); do
		echo $1
	done
fi
