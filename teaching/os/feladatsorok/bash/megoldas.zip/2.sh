#!/bin/bash

: '
	2. Írj BASH szkriptet 2.sh néven, amely két fájl elérési útvonalát kapja paraméterül! 
	A program cserélje meg a paraméterben kapott két fájl tartalmát!
'

# A csere elvégzéséhez a következő lépéseket hajtjuk végre:
#    1.) Egy ideiglenes fájlba (tmp.txt) beleírjuk az 1. paraméterben kapott fájl tartalmát.
#    2.) Az 1. paraméterben kapott fájlba beleírjuk a 2. paraméterben kapott fájl tartalmát.
#    3.) A 2. paraméterben kapott fájlba beleírjuk az ideiglenes fájl (tmp.txt) tartalmát (ez volt
#        az 1. paraméterben kapott fájl eredeti tartalma).

cat $1 > tmp.txt          # 1.) lépés
cat $2 > $1               # 2.) lépés
cat tmp.txt > $2          # 3.) lépés

# Végezetül töröljük a csere megvalósításához létrehozott ideiglenes fájlt (tmp.txt).
rm tmp.txt
