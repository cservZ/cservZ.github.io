#!/bin/bash

: '
	4. Írj BASH szkriptet 4.sh néven, amely FAJLNEV.KITERJESZTES formátumú állományneveket kap
	paraméterül (tehát a névben egyetlen pont karakter található, ami előtt a fájl neve, utána pedig a
	fájl kiterjesztése szerepel)! A szkript számolja meg, hogy hány java kiterjesztésű fájl érkezik 
	paraméterben! A kiterjesztés vizsgálatakor a kis- és nagybetűket ne különböztesd meg (tehát pl.
	Macska.java és MAIN.JAVA ugyanúgy java kiterjesztésű)!
'

# Egy változó, amivel azt fogjuk megszámolni, hogy hány Java kiterjesztésű fájl érkezik paraméterben.
# Az értékadáskor az egyenlőségjel előtt és után nem szerepelhet szóköz BASH-ben, különben hibát kapunk!

java_szamlalo=0

# Egy for-ciklussal végigmegyünk a szkript parancssori paraméterein. A $* visszaadja a paramétereket
# szóközzel elválasztva egy stringben, lényegében ezt járjuk be.

for param in $*; do
	# A kiterjesztés a pont karakter utáni rész az állománynévben (tehát darabolunk pont karakter mentén,
	# majd vesszük az így kapott második "darabot"). Mivel itt egy Linux parancsot (`cut`) akarunk
	# végrehajtani, ezért ezt backtick-ek között adjuk meg.
	
	kiterjesztes=`echo $param | cut -d '.' -f 2`
	
	# A kiterjesztésben nem szeretnénk megkülönböztetni a kis- és nagybetűket, ezért minden kiterjesztést
	# egységesen csupa kisbetűssé alakítunk a `tr` parancs segítségével.
	
	kiterjesztes=`echo $kiterjesztes | tr A-Z a-z`
	
	# Ha az így kapott, kisbetűsített kiterjesztés "java", akkor megnöveljük a számlálónk értékét 1-gyel.
	# Itt a $(( )) azért kell, hogy kiértékeljük a matematikai kifejezést, és az EREDMÉNYT adjuk értékül a 
	# változónknak. Persze ehelyett használhattuk volna pl. a let-et, vagy az `expr` parancsot is.
	
	if [[ $kiterjesztes = "java" ]]; then  # Stringek összehasonlítására 1 darab egyenlőségjelet használunk.
		java_szamlalo=$(($java_szamlalo + 1))
	fi
done

# Kiíratjuk a Java kiterjesztésű fájlok számát a konzolra. Fontos, hogy idézőjeleket használjunk a kiíratás 
# során, ha változóértékeket szeretnénk behelyettesíteni a kiíratott szövegben!

echo "$java_szamlalo darab Java kiterjesztesu fajlt kaptam parameterben."
