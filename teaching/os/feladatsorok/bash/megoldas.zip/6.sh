#!/bin/bash

: '
	6. Írj BASH szkriptet 6.sh néven, amely egy könyvtár elérési útvonalát várja paraméterben! A szkript
	írja ki a konzolra a példában látható formátumban, hogy a paraméterben kapott könyvtár txt
	kiterjesztésű fájljaiban összesen hány szó található! Amennyiben nem egy könyvtár elérési útvonala 
	érkezik paraméterben, akkor írass ki hibaüzenetet és a program lépjen ki 11-es hibakóddal!
'

# Hibakezelés: ha nem egy könyvtár érkezik 1. paraméterben, akkor 11-es hibakóddal lépünk ki a programból.
# A -d ("directory") kapcsolóval lekérdezhetjük, hogy könyvtárral (mappával) van-e dolgunk.

if [[ ! -d $1 ]]; then
	echo "HIBA! Nem egy konyvtar eleresi utvonalat adtad meg!"
	exit 11
fi

# Miután meggyőződtünk arról, hogy az 1. paraméter egy könyvtár, belelépünk (ez nem kötelező).
cd $1

# Létrehozunk egy változót, amelyben össze fogjuk adogatni a txt-fájlokban található szavak számát.
szavak_osszege=0

# Bejárjuk az aktuális mappa txt kiterjesztésű fájljait. Az aktuális mappa itt az 1. paraméterben 
# kapott mappa, mert korábban `cd`-vel beleléptünk.

for fajl in `ls *.txt`; do
	# Megszámoljuk és kiíratjuk az aktuális fájlban található szavak számát.
	
	szavak_szama=`cat $fajl | wc -w`
	echo "A(z) $fajl fajlban talalhato szavak szama: $szavak_szama"
	
	# Hozzáadjuk a szavak_osszege változó eddigi értékéhez a fájlban található szavak számát.
	szavak_osszege=$(( $szavak_osszege + $szavak_szama ))
done

# A program végén kiíratjuk a kiszámolt összeget a konzolra.

echo "------------------------------------------------------"
echo "A txt-fajlokban levo szavak szama osszesen: $szavak_osszege"
