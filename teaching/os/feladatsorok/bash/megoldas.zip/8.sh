#!/bin/bash

: '
	8. Készíts egy egyszerű számkitalálós játékot egy 8.sh nevű fájlba! A gép "gondol" egy számra 
	1 és 1000 között (az 1 és az 1000 is még beletartozik a lehetséges számok intervallumába), 
	és a felhasználó ezt a számot próbálja meg minél kevesebb próbálkozással kitalálni. A 
	felhasználónak a játék elején 20 élete (próbálkozási lehetősége) van.
'

# A legkisebb és legnagyobb szám, amire a gép még "gondolhat".

also_hatar=1
felso_hatar=1000

# Generálunk egy véletlenszerű egész számot az alsó és a felső határ között.
gondolt_szam=$(($also_hatar + $RANDOM % $felso_hatar))

# Változó a felhasználó életeinek.
eletek_szama=20

echo "Gondoltam egy szamra $also_hatar és $felso_hatar kozott, talald ki, melyikre! Eletek szama: $eletek_szama"

# Egy végtelen ciklus (ebből majd akkor lépünk ki, amikor a játék véget ér).

while true; do
	# A felhasználó tippjének beolvasása a konzolról egy tipp nevű változóba.
	
	echo -n "Tipp: "        # -n kapcsoló: nem tesz sortörést a kiíratás után
	read tipp
	
	# Ha a felhasználó nem találja el a gondolt számot, akkor kiíratjuk, hogy a gondolt szám
	# kisebb vagy nagyobb a felhasználó tippjénél. Ekkor az életek számát csökkentjük 1-gyel.
	
	if [[ $tipp -ne $gondolt_szam ]]; then
		if [[ $gondolt_szam -lt $tipp ]]; then
			echo "Kisebb"
		else
			echo "Nagyobb"
		fi
		
		eletek_szama=$(( $eletek_szama - 1 ))
	fi
	
	# Ha a felhasználó kitalálja a gondolt számot, akkor a játéknak vége és a felhasználó nyer.
	
	if [[ $tipp -eq $gondolt_szam ]]; then
		echo "-------------------------------------------------"
		echo "Gratulalok, nyertel!"
		echo "A gondolt szam valoban $gondolt_szam volt."
		echo "Megmaradt eletek: $eletek_szama."
		break                # Vége a játéknak, kilépünk a ciklusból.
	fi
	
	# Ha az életek elfogynak, akkor a játéknak vége és a felhasználó veszít.
	
	if [[ $eletek_szama -eq 0 ]]; then
		echo "-------------------------------------------------"
		echo "Sajnos nem nyertel!"
		echo "A gondolt szam $gondolt_szam volt."
		break                # Vége a játéknak, kilépünk a ciklusból.
	fi
done
