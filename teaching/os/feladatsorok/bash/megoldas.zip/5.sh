#!/bin/bash

: '
	5. Írj BASH szkriptet 5.sh néven, amely egész számokat vár paraméterül! A szkript írja ki a
	paraméterben kapott értékek közül a páros számok összegét, valamint a páratlan számok szorzatát!
	Amennyiben a szkriptet parancssori paraméterek nélkül akarjuk futtatni, akkor írasd ki a "HIBA!"
	szöveget a konzolra! Egyéb hibakezeléssel nem kell foglalkoznod.
'

# Hiányzó paraméterekre vonatkozó hibakezelés (itt $# a parancssori paraméterek száma).

if [[ $# -eq 0 ]]; then
	echo "HIBA!"
	exit 1                # Kilépés hibakóddal (ezt a feladat nem kérte).
fi

# Változók létrehozása a páros számok összegének és a páratlan számok szorzatának.

paros_osszeg=0            # Egy összeget (vagy darabszámot) tároló változót mindig 0-ról indítunk.
paratlan_szorzat=1        # Egy szorzatot tároló változót mindig 1-ről indítunk.

# Bejárjuk a parancssori paramétereket, majd a páros számokat összeadogatjuk a paros_osszeg
# változóban, a páratlan számokat pedig összeszorozgatjuk a paratlan_szorzat változóban.

for szam in $*; do
	# Mivel matematikai kifejezések EREDMÉNYÉT szeretnénk feldolgozni, ezért használjuk a
	# a $(( )) konstrukciót (vagy a let kulcsszót, esetleg az `expr` parancsot).
	
	if [[ $(($szam % 2)) -eq 0 ]]; then
		paros_osszeg=$(($paros_osszeg + $szam))
	else
		paratlan_szorzat=$(($paratlan_szorzat * $szam))
	fi
done

# A program végén kiíratjuk a kiszámolt értékeket.

echo "A paros szamok osszege: $paros_osszeg"
echo "A paratlan szamok szorzata: $paratlan_szorzat"
