<?php
	// Hiaba tartalmazza ez a fajl a kutya szoveget (tobbszor is),
	// nem foglalkozunk vele, mivel a kiterjesztes nem txt.
	
	echo "A kutya az ember legjobb baratja.";
?>
