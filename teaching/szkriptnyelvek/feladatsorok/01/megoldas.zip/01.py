# =====================================================================================================================
# 1. feladat: Összefűzés
# =====================================================================================================================

s1 = input("Az egyik szoveg: ")                     # A két szöveg beolvasása
s2 = input("A masik szoveg: ")

osszefuzott = s1 + s2                               # A két szöveg összefűzése

print("\nA ket szoveg osszefuzve:", osszefuzott)    # Az összefűzés után kapott szöveg kiíratása
