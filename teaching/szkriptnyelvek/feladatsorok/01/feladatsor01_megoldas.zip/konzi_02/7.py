# 7. FELADAT
# =================================================================================================
# A csokigyáros Jónás nyereményjátéka nagy sikert aratott a vásárlók körében. A statisztikák 
# alapján a csokigyár minden nap dupla annyi csokit ad el, mint az előző napon. Jónás ki 
# szeretné számolni, hogy egy héten várhatóan mennyi csokit fog eladni.
#
# Írj Python szkriptet, amely beolvassa a hétfőn eladott csokik számát (egész szám), majd 
# kiszámítja, hogy 7 nap alatt összesen mennyi csokit fog Jónás eladni, ha minden nap kétszer 
# annyi csokit ad el, mint az előző napon!
# =================================================================================================

# a hétfőn eladott csokik számának a beolvasása

eladott_csokik = int(input("A hétfőn eladott csokik száma: "))

# 1. megoldás: a "programozós" megközelítés

"""
osszeg = 0

for i in range(7):              # a 7 minden napján végigmegyünk...
    osszeg += eladott_csokik    # az összeghez mindig hozzáadjuk az adott napon eladott csokik számát
    eladott_csokik *= 2         # minden nap dupla annyi csokit adunk el, mint az előző napon

print("A héten", osszeg, "csokit adunk el.")    # összeg kiíratása
"""

# 2. megoldás: a "matekos" megközelítés

# ha belegondolunk, ez a feladat tulajdonképpen nem más, mint egy mértani sorozat (fancy edition)
# egy kis Google-használat után kapunk egy ilyen képletet a mértani sorozat első n elemének az összegére:
#
# S = a1 * (q^n - 1) / (q - 1), ahol:
#     - a1: a mértani sorozat első eleme (a hétfőn eladott csokik száma)
#     - q: a kvóciens, amivel mindig szorzuk (jelen esetben 2, hiszen mindennap 2-szer annyi csokit adunk el, mint előzőleg)
#     - n: most ez itt 7 lesz, hiszen 7 napra szeretnénk kiszámolni az eladott csokik számát
#
# a megfelelő adatok behelyettesítésével a következőt kapjuk:

osszeg = eladott_csokik * (2 ** 7 - 1) // (2 - 1)   # itt egészosztás kell, mert a sima per valós számot adna vissza (vagy akár használhatjuk az int() függvényt is)
print(osszeg)