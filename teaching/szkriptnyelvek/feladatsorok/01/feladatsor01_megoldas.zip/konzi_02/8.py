# 8. FELADAT
# =================================================================================================
# Pomeló Zoltán egy zöldségesboltot üzemeltet. Ahhoz, hogy az árakat könnyebben tudja 
# számolni, szüksége van egy számológépre.
#
# Írj Python nyelven egy egyszerű számológépet, amely a négy alapműveletet (összeadás, 
# kivonás, szorzás, osztás) tudja értelmezni!
#
# - A program beolvas két valós számot és egy műveleti jelet (szöveg).
# - Ha a műveleti jel helyes (+, -, *, / szimbólumok valamelyike), végezzük el a 
#   megfelelő műveletet!
# - A felsorolt négy jeltől eltérő műveleti jel esetén írassunk ki hibaüzenetet!
# - Kezeljük le a nullával osztás esetét is: ha nullával szeretnénk osztani, írassunk ki 
#   hibaüzenetet!
# =================================================================================================

# input adatok beolvasása

a = float(input("Első szám: "))            # most valós számokkal dolgozunk, így a float()-ot használjuk
b = float(input("Második szám: "))
op = input("Művelet: ")                    # a műveleti jel string típusú, ekkor nem kell konvertálnunk

# számítás elvégzése

if op == "+":
    print("Az eredmény:", a+b)
elif op == "-":
    print("Az eredmény:", a-b)
elif op == "*":
    print("Az eredmény:", round(a*b, 2))
elif op == "/":
    if b == 0:          # nullával való osztás kezelése
        print("HIBA: Nullával nem osztunk!")
    else:
        print("Az eredmény:", round(a/b, 2))
else:                   # érvénytelen műveleti jel kezelése
    print("HIBA: Érvénytelen művelet!")

# MEGJEGYZÉS: a round() segítségével elérjük, hogy a szorzat és
# a hányados 2 tizedesjegy pontossággal jelenjen meg