# 9. FELADAT
# =================================================================================================
# Zoltán egyik nap úgy döntött, hogy szeretné, ha a számológépe négyzetgyököt is tudna vonni.
#
# Készíts Python szkriptet, amely beolvas egy egész számot a konzolról! Ha ez a szám 
# nemnegatív, a program számítsa ki a négyzetgyökét! Ellenkező esetben, ha a szám negatív, 
# írass ki hibaüzenetet! Tipp: n négyzetgyöke megyezik az n^(1/2) értékével.
# =================================================================================================

# input adat beolvasása + konvertálás egész típusra

szam = int(input("Adj meg egy számot: "))

# negatív számok esetén hibaüzenet, egyébként pedig kiszámítjuk a négyzetgyök értéket

if szam < 0:
    print("Negatív számból nem vonunk négyzetgyököt!")  # legalábbis valós számok körében :)
else:
    negyzetgyok = szam ** 0.5                           # használjuk a feladatban szereplő összefüggést
    print(szam, "négyzetgyöke:", negyzetgyok)