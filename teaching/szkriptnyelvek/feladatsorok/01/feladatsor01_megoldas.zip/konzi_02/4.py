# 4. FELADAT
# =================================================================================================
# Noémi, a Flying Duck Travels légitársaság utaskísérője munkájából kifolyólag sokat utazik a 
# világban. Egyik kedvenc látnivalója az egyiptomi piramisok.
#
# Írj Python programot, amely beolvas egy magasság értéket (egész szám), majd kirajzol a 
# konzolra egy ilyen magas piramist "*" (csillag) karakterekből, a példán látható módon! 
# Hibakezeléssel nem kell foglalkoznod.
# =================================================================================================

# magasság beolvasása + konvertálás egész értékre

magassag = int(input("Add meg, hogy milyen magas legyen a piramis: "))

# az egyes sorban szereplő csillagok és helyközök darabszámát meghatározó változók

darabszam = 1                   # az első sorban 1 darab csillag szerepel
helykoz = magassag - 1          # az első sorban (magassag - 1) darab helyköz szerepel

# a piramis kirajzolása

for i in range(magassag):       # magassag darab sorból fog állni a piramis
    print(" " * helykoz + "*" * darabszam)  # helyközök és csillagok kiíratása
    darabszam += 2              # minden sorban 2-vel több csillag lesz, mint az előzőben
    helykoz -= 1                # minden sor elején 1-gyel kevesebb helyköz lesz, mint az előzőben