# 10. FELADAT
# =================================================================================================
# Készíts egy egyszerű számkitalálós játékot Python nyelven! A gép “gondol” egy számra 1 és 
# 1000 között (az 1 és az 1000 is még beletartozik a lehetséges számok intervallumába), és a 
# felhasználó ezt a számot próbálja meg minél kevesebb próbálkozással kitalálni. A 
# felhasználónak a játék elején 20 élete (próbálkozása) van.
#
# - Hozz létre egy változót a felhasználói életeinek számára! Ez kezdetben legyen 20!
# - Hozz létre egy változót a gondolt számnak! Ez lehet fix szám vagy véletlenszerűen 
#   generált érték.
# - A játék során minden körben olvasd be a felhasználó aktuális tippjét a konzolról (egész szám)!
# - Ha a felhasználó nem találja el a gondolt számot, akkor írasd ki, hogy a gondolt szám kisebb-e 
#   vagy nagyobb-e a felhasználó tippjénél! Csökkentsd a felhasználó életeinek számát 1-gyel!
# - Ha a felhasználó eltalálja a gondolt számot, akkor a játéknak vége, és a felhasználó nyert. 
#   Ebben az esetben írasd ki a Gratuálok, nyertél! szöveget, a gondolt számot és 
#   a megmaradt életek számát!
# - Ha elfogynak a felhasználó életei, akkor a játéknak vége, és a felhasználó veszít. Ebben az 
#   esetben írasd ki a Sajnos nem nyertél! szöveget, és a gondolt számot!
# =================================================================================================

import random                               # randomszám-generáláshoz szükséges ez a modul

eletek_szama = 20                           # kezdetben 20 próbálkozási lehetőségünk van
gondolt_szam = random.randint(1, 1000)      # generálunk egy 1 és 1000 közötti véletlenszámot

print("Gondoltam egy számra 1 és 1000 között, találd ki melyikre! Életek száma: 20")

while True:                                 # végtelen ciklus (amíg ez fut, addig tart a játék)
    tipp = int(input("Tipp: "))             # felhasználó tippjének beolvasása

    if tipp != gondolt_szam:                # ha nem találta el a felhasználó a gondolt számot...
        if gondolt_szam < tipp:             # ...kiíratjuk, hogy az kisebb vagy nagyobb-e, mint a tippelt érték
            print("Kisebb")
        else:
            print("Nagyobb")

        eletek_szama -= 1                   # ...csökkentjük a próbálkozási lehetőségek számát

    if tipp == gondolt_szam:                # ha eltaláltuk a gondolt számot... winner winner, chicken dinner :)
        print("Gratulálok, nyertél!")
        print("A gondolt szám valóban", gondolt_szam, "volt.")
        print("Megmaradt életek:", eletek_szama)
        break

    if eletek_szama == 0:                   # ha kifogyunk az életekből... well, F :(
        print("Sajnos nem nyertél!")
        print("A gondolt szám", gondolt_szam, "volt.")
        break