# 6. FELADAT
# =================================================================================================
# A szkriptnyelvek gyakorlat osztályozása a következő ponthatárok alapján történik:
#
# |  Ponthatárok  |   Érdemjegy   |
# |:-------------:|:-------------:|
# | 89 - 100 pont | Jeles (5)     |
# |  76 - 88 pont | Jó (4)        |
# |  63 - 75 pont | Közepes (3)   |
# |  50 - 62 pont | Elégséges (2) |
# |  0 - 49 pont  | Elégtelen (1) |
#
# Írj Python programot, amely beolvassa a gyakorlaton elért pontszámot (egész szám), és 
# kiírja a pontszámnak megfelelő érdemjegyet!
# =================================================================================================

# pontszám beolvasása + konvertálás egész típusra

pontszam = int(input("A pontszámod: "))

# pontszámhoz tartozó szöveges értékelés megállapítása, kiíratása

if 89 <= pontszam <= 100:
    print("Jeles")
elif 76 <= pontszam <= 88:
    print("Jó")
elif 63 <= pontszam <= 75:
    print("Közepes")
elif 50 <= pontszam <= 62:
    print("Elégséges")
elif 0 <= pontszam <= 49:
    print("Elégtelen")
else:
    print("HIBA: Érvénytelen pontszám!")

# MEGJEGYZÉS: itt használhatnánk logikai operátort is a feltételek megadására:
# if pontszam >= 89 and pontszam <= 100
# Viszont a fenti megoldás valamivel elegánsabb :)