# 2. FELADAT
# =================================================================================================
# Egy moziban összesen 40 szék van, amelyek 1-től 40-ig vannak számozva. Azért, hogy a 
# moziba járók be tudják tartani a javasolt másfél méteres védőtávolságot, a mozi üzemeltetői 
# úgy döntenek, hogy csak minden harmadik ülőhelyet engednek lefoglalni a weboldalukon.
#
# Írj Python szkriptet, amely kiírja 1-től 40-ig minden harmadik szék szám
# A kiíratás az 1-es sorszámú székkel kezdődjön!
# =================================================================================================

# menjünk végig az 1 és 40 közti egész számokon, 3-as lépésközzel egy for-ciklust használva
# ha 40-ig mennénk, akkor a 40 még nem tartozna bele a megvizsgált számok intervallumába (viszont a 40 pont kelleni fog az outputban)
# megoldás: ne 40-ig menjünk, hanem 41-ig

for i in range(1, 41, 3):
    print(i)