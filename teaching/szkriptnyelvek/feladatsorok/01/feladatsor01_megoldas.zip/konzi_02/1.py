# 1. FELADAT
# =================================================================================================
# A gimnazista Károly informatikaórán odafigyelés helyett mémeket nézegetett, 
# ezért az informatikatanártól azt a régimódi büntetést kapta, hogy le kell írnia a nevét 100-szor.
#
# Írj Python szkriptet, amely kiírja a konzolra a Károly szöveget 100 alkalommal!
# =================================================================================================

# 1. megoldás: while-ciklus

"""
i = 0

while i < 100:
    print("Károly")
    i += 1                  # emlékeztető: Pythonban nincs i++
"""

# 2. megoldás: for-ciklus

"""
for i in range(100):
    print("Károly")
"""

# 3. megoldás: string többszörözés

print("Károly\n" * 100)     # ha egy stringet szeretnénk többször kiíratni, akkor voltaképp nem is kell ciklus :)