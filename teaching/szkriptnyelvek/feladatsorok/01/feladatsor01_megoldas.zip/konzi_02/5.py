# 5. FELADAT
# =================================================================================================
# Ricsi idén elhatározta, hogy minél jobb átlagot szeretne elérni az egyetemen, hogy az 
# ösztöndíjból egy új laptopot vehessen.
#
# Írj Python szkriptet, amely először beolvassa, hogy hány jegyet kapott Ricsi összesen a 
# félévben (egész szám), majd ezt követően beolvas ennyi darab érdemjegyet (egész számok)! 
# A szkript számítsa ki a jegyek átlagát! Az átlagot a jegyek összegének és darabszámának 
# hányadosaként kapjuk meg.
# =================================================================================================

# jegyek darabszámának beolvasása + konvertálás egész értékre

darabszam = int(input("Hány jegyet kaptál? "))

# "darabszam" darab érdemjegy beolvasása

print("Add meg a jegyeidet:")

i = 0
osszeg = 0                      # az érdemjegyek összege (az átlaghoz kell)

while i < darabszam:
    jegy = int(input())
    osszeg += jegy              # mindig hozzáadjuk az akutális érdemjegyet az összeghez      
    i += 1

# átlag kiszámítása és kiíratása

atlag = osszeg / darabszam      # az átlag az összeg és a darabszám hányadosa
print("A jegyek átlaga: " + str(atlag))