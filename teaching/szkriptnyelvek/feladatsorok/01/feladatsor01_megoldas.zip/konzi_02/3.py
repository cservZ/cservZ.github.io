# 3. FELADAT
# =================================================================================================
# Jónás, a csokigyáros úgy döntött, hogy nyereményjátékot hirdet: minden 10. legyártott tábla 
# csokoládéba egy aranyszelvényt helyez. A szelvények szerencsés megtalálói egy különleges 
# látogatást tehetnek Jónás csokigyárába.
#
# Írj Python szkriptet, amely beolvassa a konzolról egy csoki gyártási sorszámát (egész szám). 
# Ha a szám 10-zel osztható, akkor írasd ki a "Gratulálok, nyertél!", ellenkező esetben pedig a 
# "Sajnos nem nyert!" szöveget a konzolra!
# =================================================================================================

# input adat beolvasása + konvertálás egész típusra

gyartasi_szam = int(input("Csoki gyártási száma: "))

# feltételvizsgálat: osztható-e a gyártási szám 10-zel

if gyartasi_szam % 10 == 0:
    print("Gratulálok, nyertél!")
else:
    print("Sajnos nem nyertél!")