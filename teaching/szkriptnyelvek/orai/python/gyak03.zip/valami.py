# Ebben a fájlban beimportáljuk a `fuggvenyek.py` fájlt egy modulként. Ha ezt a fájlt futtatjuk le, akkor a
# `fuggvenyek.py`-ban szereplő `if __name__ == '__main__'` feltétel hamisra értékelődik ki.

import fuggvenyek

fuggvenyek.hello()
