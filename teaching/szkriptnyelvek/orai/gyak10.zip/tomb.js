// === Tömbök létrehozása. ===

const tomb1 = [7, 4, 1, 2, 5, 9];
const tomb2 = ["macska", 3.14, true, undefined];        // A tömbökben akár eltérő típusú adatokat is tárolhatunk.

// FELADAT: Ellenőrizzük, hogy a `tomb1` változó egy tömböt tárol-e!

// MEGOLDÁS: Itt nem a sima `typeof`-ot fogjuk használni, mert ez tömbök és object-ek esetén is az "object" szöveggel
// tér vissza, hiszen JavaScriptben minden tömb egyben egy objektum is. Ahhoz, hogy különbséget tudjunk tenni a tömbök
// és az objektumok között, a következőképpen végezzük el tömbök esetén a típusellenőrzést: `tombNeve instanceof Array`
// (tehát azt nézzük meg, hogy a beépített Array (tömb) osztály példánya-e az objektum).

console.log("tomb1 tömb típusú:", tomb1 instanceof Array);

// === Tömbök hosszának lekérdezése. ===

console.log("tomb1 hossza:", tomb1.length);

// === Tömbök indexelése. ===

console.log(tomb1);
console.log("A legelső tömbelem:", tomb1[0]);
console.log("Az utolsó tömbelem:", tomb1[tomb1.length - 1]);
console.log(tomb1[-1]);                         // A negatív indexelés természetesen tömbök esetén sem működik.

tomb1[0] = 8;                                   // Ez így okés, mert a tömb egy mutable (módosítható) típus.
console.log(tomb1);
console.log("----------------------------------------------------------------------");

// === Tömbök bejárása. ===

for (let i = 0; i < tomb1.length; i++)          // Index alapú bejárás.
    console.log(tomb1[i]);

console.log("----------------------------------------------------------------------");

for (let elem of tomb1)                        // Listaszerű bejárás.
    console.log(elem);

console.log("----------------------------------------------------------------------");

// FELADAT: Írassuk ki, hogy a `tomb1` tömbben lévő számok közül melyik a legnagyobb!

// MEGOLDÁS: Írhatnánk akár egy maximumkeresést is, viszont a `Math.max()` függvényt is használhatjuk. Ez visszaadja a
// paraméterben kapott számok maximumát (pl. `Math.max(1, 3, 2)` értéke `3`). JavaScriptben a `Math.max()`-ot tömbökre
// nem tudjuk használni (ekkor `NaN`-t kapunk). Ahhoz, hogy megkeressük a maximális tömbelemet, először "ki kell
// csomagolni" a tömbelemeket a `...` operátorral (így pl. `...[1, 3, 2]`-ből kapunk egy `1 3 2` sorozatot).

// console.log("A legnagyobb szám:", Math.max(tomb1));   // Hibás! `NaN` értéket kapunk!
console.log("A legnagyobb szám:", Math.max(...tomb1));   // A "kicsomagolt" tömbelemeket kell átadni a `Math.max()`-nak.

// === Referencia szerinti működés. ===

const nullaz = tomb => {      // Egy függvény (arrow function), amely kinullázza a paraméterben kapott tömb elemeit.
  for (let i = 0; i < tomb.length; i++)
      tomb[i] = 0;

  return tomb;
};

// A tömbök JavaScriptben is referencia szerint működnek. Ha egy függvénynek átadunk egy tömböt paraméterül, akkor
// az eredeti tömböt adjuk át (nem egy másolatot), így ha a függvényen belül módosítjuk a tömböt, akkor az eredeti
// tömbre is érvényesek lesznek a módosítások. Ha ezt nem szeretnénk, akkor adjunk át egy másolatot a tömbünkről!
// (Egy `t` tömb lemásolásának szintaxisa JavaScriptben: `[...t]`.)

// console.log(nullaz(tomb1));                // Ekkor a `tomb1` tartalma is módosulna!
console.log(nullaz([...tomb1]));        // Ha másolatot adunk át a tömbünkről, akkor az eredeti tömb nem módosul.
console.log(tomb1);
console.log("----------------------------------------------------------------------");

const tomb3 = [1, 2, 3, 4, 5];

// FELADAT: Duplázzuk meg a `tomb3` tömbben szereplő számokat! A duplázott értékeket adjuk vissza egy új tömbben!

// MEGOLDÁS: A feladat nyilván megoldható algoritmikusan. Ha van egy ilyen feladatunk, hogy "egy tömb minden elemére
// hajtsunk végre valamilyen műveletet" (pl. mindenkit duplázzunk meg), akkor ezt 1 sorban is megoldhatjuk a `map()`
// metódus használatával. A `map()` metódus egy callback függvényt vár paraméterben, amit minden tömbelemre meghív.
// A callback függvény paramétere lesz az aktuális tömbelem, visszatérési értéke pedig a végrehajtandó művelet
// (most minden tömbelemnek venni fogjuk a kétszeresét).

const duplazott = tomb3.map(elem => 2 * elem);  // A callback függvény az `elem => { return 2 * elem; }` rövidítése.
console.log("A duplázás után:", duplazott);

// FELADAT: Válogassuk ki a `tomb3` tömbben szereplő értékek közül a páros számokat egy új tömbbe!

// MEGOLDÁS: A feladat nyilván megoldható algoritmikusan. Ha van egy ilyen feladatunk, hogy "egy tömbből válogassuk ki
// azokat az elemeket, amelyek valamilyen feltételnek eleget tesznek" (pl. párosak), akkor ezt 1 sorban is megoldhatjuk
// a `filter()` metódussal. A metódus egy callback függvényt vár paraméterben, amit minden tömbelemre meghív. A callback
// függvény paramétere az aktuális tömbelem, visszatérési értéke egy feltétel. A `filter()` hatására visszakapjuk egy
// új tömbben azokat az elemeket, amelyek a megadott feltételnek eleget tesznek (itt: a páros számokat).

const parosak = tomb3.filter(elem => elem % 2 === 0);
console.log("A páros számok:", parosak);

// FELADAT: Számoljuk ki a `tomb3` tömbben szereplő számok összegét!

// MEGOLDÁS: A feladat nyilván megoldható algoritmikusan. Ha van egy ilyen feladatunk, hogy "számoljunk ki valamit a
// tömbelemek alapján" (pl. az elemek összegét), akkor ezt 1 sorban is megoldhatjuk a `reduce()` metódussal. A metódus
// egy callback függvényt vár paraméterben, amit minden tömbelemre meghív. A callback függvénynek két paramétere lesz:
// az előzőleg kiszámolt érték (itt: a korábban szereplő tömbelemek összege) és az aktuális tömbelem, a visszatérési
// érték pedig a számítás mikéntjét határozza meg (itt: hozzáadjuk a korábbi elemek összegéhez az aktuális elemet).
// A callback függvény után, a `reduce()` metódus második paramétereként megadható a kiszámított érték kezdőértéke
// (pl. az összeget 0-ról indítjuk, de mondjuk egy szorzatot 1-ről indítanánk).

const osszeg = tomb3.reduce((elozoErtek, aktualisElem) => elozoErtek + aktualisElem, 0);
console.log("A számok összege:", osszeg);

console.log("----------------------------------------------------------------------");

// === Stringekből tömbök, tömbökből stringek. ===

let szoveg = "    Never gonna give you up            ";
szoveg = szoveg.trim();                                     // String elején és végén lévő helyközök eltávolítása.
console.log("A whitespace-ek nélküli szöveg:", szoveg);

const szavak = szoveg.split(" ");                   // String -> tömb
console.log("A szöveg szavai:", szavak);

const nagybetusSzavak = szavak.map(szo => szo.toUpperCase());
console.log("A szavak csupa nagybetűkkel:", nagybetusSzavak);

const nagybetusSzoveg = nagybetusSzavak.join(" ");          // Tömb -> string
console.log(nagybetusSzoveg);
console.log("----------------------------------------------------------------------");

// === Tömbkezelő függvények. ===

const tomb4 = [7, 4, 1, 2, 5];
console.log(tomb4);

tomb4.pop();                    // Tömb végén lévő elem törlése.
console.log(tomb4);
tomb4.push(8);                  // Elem beszúrása a tömb végére.
console.log(tomb4);

tomb4.shift();                  // Tömb elején lévő elem törlése.
console.log(tomb4);
tomb4.unshift(10);        // Elem beszúrása a tömb elejére.
console.log(tomb4);

const resztomb = tomb4.slice(1, 4); // Résztömb lekérése.
console.log("Az 1-4. indexek közötti tömbelemek:", resztomb);

console.log(tomb4.includes(4));     // Tömbelem előfordulásának ellenőrzése (1. módszer).
console.log(tomb4.indexOf(4));      // Tömbelem előfordulásának ellenőrzése (2. módszer).

// Tömbelemek rendezése. Itt a probléma az, hogy a `sort()` metódus minden esetben stringekként rendezi a tömbelemeket.
// Ha számokként akarjuk rendezni az elemeket, akkor egy callback függvényt kell megadnunk a `sort()` metódusnak.
// Bővebb leírás itt: https://www.w3schools.com/js/js_array_sort.asp

// tomb4.sort();                                            // Nem jó! Ez betűrendbe rendezné a számokat.
tomb4.sort((a, b) => a - b);      // Növekvő sorrendbe rendezés.
console.log("A rendezett tömb:", tomb4);
console.log("----------------------------------------------------------------------");

// === Kétdimenziós tömbök létrehozása és bejárása. ===

const matrix = [[1, 2, 3], [4, 5, 6]];

for (let i = 0; i < matrix.length; i++)
    for (let j = 0; j < matrix[0].length; j++)
        console.log(matrix[i][j]);
