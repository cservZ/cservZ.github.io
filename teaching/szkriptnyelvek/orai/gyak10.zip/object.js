// === Object létrehozása (property-érték párokból áll). ===

const programozasiNyelv = {nev: "JavaScript", kiadasEve: 1995, logikus: false}; // A property neve tetszőleges lehet.
console.log(programozasiNyelv);

// === Adott property-hez tartozó érték lekérdezése. ===

console.log(programozasiNyelv["nev"]);                      // 1. módszer: szögletes zárójelek.
console.log(programozasiNyelv.nev);                         // 2. módszer: pont operátor.

// Ha egy változónk van, akkor...
//   ...a szögletes zárójeles megadási mód a változó értékét tekinti a property nevének (helyes).
//   ...a pontot használó megadási mód a változó nevét tekinti a property nevének (hibás).

const propertyNeve = "kiadasEve";

console.log(programozasiNyelv[propertyNeve]);
console.log(programozasiNyelv.propertyNeve);                // Nem jó! Itt egy `propertyNeve` nevű property-t keresünk.
console.log("-------------------------------------------------------------------------------");

// === Property előfordulásának ellenőrzése. ===

if (programozasiNyelv["kiadasEve"] !== undefined)           // A nem létező property-khez az `undefined` érték tartozik.
    console.log("A kiadasEve property szerepel az objektumban.");

// KÉRDÉS: Mi van akkor, ha a property szerepel az object-ben, de az `undefined` érték tartozik hozzá?

// VÁLASZ: Ekkor a fenti megoldás nem jól működik. Ha precízek akarunk lenni, akkor az `in` operátorral tudjuk megnézni,
// hogy egy property benne van-e egy object-ben. (Ilyen "szélsőséges" esetünk egyébként ZH-ban nem lesz. Bőven elég
// számunkra, ha az előző `if`-ben látott módon ellenőrizzük a property meglétét.)

if ("kiadasEve" in programozasiNyelv)                       // Precíz megoldás.
    console.log("A kiadasEve property szerepel az objektumban.");

console.log("-------------------------------------------------------------------------------");

// === Property-hez tartozó érték módosítása. ===

programozasiNyelv["logikus"] = true;
console.log(programozasiNyelv);

// === Új property-érték pár beszúrása. ===

programozasiNyelv["keszito"] = "Brendan Eich";
console.log(programozasiNyelv);

// === Property-érték pár törlése. ===

delete programozasiNyelv["kiadasEve"];
console.log(programozasiNyelv);
console.log("-------------------------------------------------------------------------------");

// === Object bejárása. ===

// Az `Object.entries()` egy kétdimenziós tömböt ad vissza, amelynek a résztömbjei 2 eleműek. Az első elem a property
// neve, a második elem pedig a property-hez tartozó érték. (Tehát valami ilyesmi: `[ [p1, e1], [p2, e2], ... ]`.)

for (let [prop, ertek] of Object.entries(programozasiNyelv))
    console.log(prop, "értéke:", ertek);
