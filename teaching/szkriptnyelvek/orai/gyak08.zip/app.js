console.log("Hello from the other file!");
