<?php
    include_once "classes/Felhasznalo.php";
    include_once "common/fuggvenyek.php";
    session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Kosaram</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("cart");
    ?>

    <main>
        <h1 class="center">Kosaram</h1>
        <p class="center strong">Az oldal fejlesztés alatt áll! Nézz vissza később!</p>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>