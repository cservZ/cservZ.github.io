<?php

session_start();

// Írjuk meg az oldalról való kijelentkezést megvalósító PHP kódot!

