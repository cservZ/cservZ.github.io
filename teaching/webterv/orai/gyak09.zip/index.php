<?php
    include_once "common/fuggvenyek.php";
    session_start();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Főoldal</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("index");
    ?>

    <main>
        <h1 class="center">Üdv az Irinyi Pizzázóban!</h1>
        <img src="assets/img/icon.png" alt="Pizza" height="200">

        <section>
            <h2>Magunkról</h2>
            <p>
                Megéheztél az órák között? Megünnepelnéd a jól sikerült CooSpace-es ZH-dat egy pizzázással? Vagy éppen a
                nulla pontosra sikerült Bírós ZH-d után szeretnél egy kis pizzával vigasztalódni? Bármi is legyen a
                szituáció, az Irinyi Pizzázóban minden informatikus hallgató megtalálja Szeged legjobb pizzáit.
                Pizzakészítőink sok éves tapasztalattal (és még annál is több Kalkulus tárgyfelvétellel) minden nap arra
                törekszenek, hogy finomabbnál finomabb pizzák várják a pizzázónkba látogatókat. Nézz be hozzánk, és kóstold meg a pizzáinkat!
            </p>
            <p><strong>Helyszín:</strong> Szeged, Tisza Lajos krt. 103</p>
            <p><strong>E-mail cím:</strong> irinyipizza@inf.u-szeged.hu</p>
        </section>

        <hr>

        <section>
            <h2>Nyitvatartás</h2>
            <p>Ugorj be hozzánk nyitvatartási időben, és mi mindig finom pizzákkal fogunk téged várni!</p>
            <table>
                <tr>
                    <th></th>
                    <th id="nyitas">Nyitás</th>
                    <th id="zaras">Zárás</th>
                </tr>
                <tr>
                    <th id="hetkoznap">Hétfő - Péntek</th>
                    <td headers="hetkoznap nyitas">08:00</td>
                    <td headers="hetkoznap zaras">16:00</td>
                </tr>
                <tr>
                    <th id="hetvege">Szombat - Vasárnap</th>
                    <td headers="hetvege" colspan="2">Zárva</td>
                </tr>
            </table>
        </section>

        <hr>

        <section>
            <h2>Jogi nyilatkozat</h2>

            <p>Pizzázónkat nem terheli felelősség abban az esetben, ha...</p>
            <ul>
                <li>
                    ...a vendég fejére hullik az épület vakolata.
                </li>
                <li>
                    ...a mosdóban elfogyott a krémszappan.
                </li>
                <li>
                    ...a vendéget zavarja az itt étkezők hangos beszélgetése (személyzetünk túlságosan introvertált
                    ahhoz, hogy bárkire rászóljon).
                </li>
                <li>
                    ...az épületben található rádióban éppen a Never Gonna Give You Up című sláger szól, és a vendég
                    esetlegesen rick roll-olva érzi magát.
                </li>
            </ul>
        </section>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>