<?php

// Egy függvény, amely legenerálja a navigációs menüt. A függvényhíváskor az $aktualisOldal értéke jelzi, hogy
// melyik menüpont tartozik az aktuális oldalhoz (ehhez a menüponthoz hozzárendeljük a class="active" attribútumot).
// A "Kosaram" és "Profilom" oldalakat csak a bejelentkezett felhasználók látják, a nem bejelentkezett felhasználóknak
// a "Bejelentkezés" és "Regisztráció" oldalakat jelenítjük meg.

function navigacioGeneralasa(string $aktualisOldal) {
    echo "<nav><ul>" .
    "<li" . ($aktualisOldal === "index" ? " class='active'" : "") . ">" .
        "<a href='index.php'>Főoldal</a>" .
    "</li>" .
    "<li" . ($aktualisOldal === "pizza" ? " class='active'" : "") . ">" .
        "<a href='pizza.php'>Pizzák</a>" .
    "</li>";

    if (isset($_SESSION["user"])) {
        echo "<li" . ($aktualisOldal === "cart" ? " class='active'" : "") . ">" .
        "<a href='cart.php'>Kosaram</a>" .
        "</li>" .
        "<li" . ($aktualisOldal === "profile" ? " class='active'" : "") . ">" .
        "<a href='profile.php'>Profilom</a>" .
        "</li>" .
        "</ul></nav>";
    } else {
        echo "<li" . ($aktualisOldal === "login" ? " class='active'" : "") . ">" .
        "<a href='login.php'>Bejelentkezés</a>" .
        "</li>" .
        "<li" . ($aktualisOldal === "signup" ? " class='active'" : "") . ">" .
        "<a href='signup.php'>Regisztráció</a>" .
        "</li>" .
        "</ul></nav>";
    }
}

// Egy függvény, amely a második paraméterben kapott adattömb elemeit szerializálja és elmenti az első paraméterben
// kapott elérési útvonalon található fájlba.

function adatokMentese(string $fajlnev, array $adatok) {
    $file = fopen($fajlnev, "w");

    if (!$file) {
        die("Nem sikerült a fájl megnyitása!");
    }

    foreach ($adatok as $adat) {
        fwrite($file, serialize($adat) . "\n");
    }

    fclose($file);
}

// Egy függvény, amely a paraméterben kapott elérési útvonalon található fájlból beolvassa az adatokat.
// A függvény visszatérési értéke egy tömb, ami a PHP értékké alakított (más szóval deszerializált) adatokat tárolja.

function adatokBetoltese(string $fajlnev): array {
    $file = fopen($fajlnev, "r");
    $adatok = [];

    if (!$file) {
        die("Nem sikerült a fájl megnyitása!");
    }

    while (($sor = fgets($file)) !== false) {
        $adat = unserialize($sor);
        $adatok[] = $adat;
    }

    fclose($file);
    return $adatok;
}

// Egy függvény, amely megvalósítja a profilkép feltöltését. A függvény első paramétereként a fájlfeltöltés során
// adódó esetleges hibák tárolására szolgáló tömböt kell megadni, a második paraméterként pedig a bejelentkezett
// felhasználó nevét (hiszen a felhasználó neve lesz a feltöltött fájl neve).

function profilkepFeltoltese(array &$hibak, string $felhasznalonev) {
    // Először érdemes megnézni, hogy ténylegesen feltöltött-e egy fájlt a felhasználó.

    if (isset($_FILES["profile-picture"]) && is_uploaded_file($_FILES["profile-picture"]["tmp_name"])) {
        // Hibakezelés: a fájlfeltöltés során adódó esetleges hibák.
        if ($_FILES["profile-picture"]["error"] !== 0) {
            $hibak[] = "Hiba történt a fájlfeltöltés során!";
        }

        // Csak PNG és JPG kiterjesztésű képeket szeretnénk elfogadni.
        $engedelyezettKiterjesztesek = ["png", "jpg"];

        // A feltöltött fájl kiterjesztésének lekérdezése.
        $kiterjesztes = strtolower(pathinfo($_FILES["profile-picture"]["name"], PATHINFO_EXTENSION));

        // Hibakezelés: nem megfelelő kiterjesztés.
        if (!in_array($kiterjesztes, $engedelyezettKiterjesztesek)) {
            $hibak[] = "A profilkép kiterjesztése hibás! Engedélyezett formátumok: " .
            implode(", ", $engedelyezettKiterjesztesek) . "!";
        }

        // Hibakezelés: túl nagy (5 MB-nál nagyobb) fájl.
        if ($_FILES["profile-picture"]["size"] > 5242880) {
            $hibak[] = "A fájl mérete túl nagy!";
        }

        // Ha nem volt hiba, akkor összeállítjuk a profilkép mentési útvonalát, és megpróbáljuk elmenteni a fájlt.
        if (count($hibak) === 0) {
            $utvonal = "assets/img/profile-pictures/$felhasznalonev.$kiterjesztes";
            $flag = move_uploaded_file($_FILES["profile-picture"]["tmp_name"], $utvonal);

            // Hibakezelés: sikertelen átmozgatás.
            if (!$flag) {
                $hibak[] = "A profilkép elmentése nem sikerült!";
            }
        }
    }
}