<?php

class Pizza {
    private string $nev;
    private int $ar;
    private array $feltetek;

    // Konstruktor

    public function __construct(string $nev, int $ar, array $feltetek) {
        $this->nev = $nev;
        $this->ar = $ar;
        $this->feltetek = $feltetek;
    }

    // Getterek és setterek

    public function getNev(): string {
        return $this->nev;
    }

    public function setNev(string $nev): void {
        $this->nev = $nev;
    }

    public function getAr(): int {
        return $this->ar;
    }

    public function setAr(int $ar): void {
        $this->ar = $ar;
    }

    public function getFeltetek(): array {
        return $this->feltetek;
    }

    public function setFeltetek(array $feltetek): void {
        $this->feltetek = $feltetek;
    }

    // Az objektum szöveggé alakításáért felelő metódus

    public function __toString(): string {
        return $this->nev . ", ár: " . $this->ar . " forint, feltétek: " . implode(", ", $this->feltetek);
    }
}