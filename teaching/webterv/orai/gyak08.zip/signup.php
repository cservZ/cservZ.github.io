<?php
    include_once "classes/Felhasznalo.php";
    include_once "common/fuggvenyek.php";

    // Az összes felhasználó betöltése egy tömbbe.
    $felhasznalok = adatokBetoltese("data/felhasznalok.txt");

    // A regisztráció során keletkező esetleges hibákat ebben a tömbben fogjuk eltárolni.
    $hibak = [];

    // Ha a felhasználó rákattintott a "Regisztráció" gombra, akkor elmentjük a begépelt adatokat egy-egy változóba.
    // (MEGJEGYZÉS: A profilkép feltöltése funkciót majd egy későbbi gyakorlaton fogjuk működőképessé tenni.)

    if (isset($_POST["signup-btn"])) {
        $felhasznalonev = $_POST["username"];
        $jelszo = $_POST["password"];
        $ellenorzoJelszo = $_POST["password2"];
        $email = $_POST["email"];
        $szuletesiEv = $_POST["year-of-birth"];
        $jelolonegyzetek = $_POST["confirmations"];
        $nem = "egyéb";

        if (isset($_POST["gender"])) {
            $nem = $_POST["gender"];
        }

        // Ellenőrizzük, hogy a kötelezően kitöltendő mezők ténylegesen ki lettek-e töltve adattal!

        // Ellenőrizzük, hogy csak olyan felhasználónévvel lehessen regisztrálni, ami még nem foglalt!

        // Ellenőrizzük, hogy a jelszó hossza legalább 5 karakter legyen!

        // Érjük el, hogy a jelszónak tartalmaznia kelljen betűt és számjegyet is!

        if (!preg_match("/[A-Za-z]/", $jelszo) || !preg_match("/[0-9]/", $jelszo)) {
            $hibak[] = "A jelszónak tartalmaznia kell betűt és számjegyet is!";
        }

        // Ellenőrizzük, hogy az űrlapon megadott e-mail cím formátuma megfelelő-e!

        if (!preg_match("/[0-9a-z.-]+@([0-9a-z-]+\.)+[a-z]{2,4}/", $email)) {
            $hibak[] = "A megadott e-mail cím formátuma nem megfelelő!";
        }

        // Ellenőrizzük, hogy a jelszó és az ellenőrző jelszó megegyezik-e!

        // Ellenőrizzük, hogy csak olyan e-mail címmel lehessen regisztrálni, ami még nem foglalt!

        // Ellenőrizzük, hogy mindkét jelölőnégyzetet bejelölte-e a felhasználó!

        // Ha az űrlapon megadott adatok helyesek, akkor mentsük el a felhasználó adatait!

    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Regisztráció</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("signup");
    ?>

    <main>
        <h1 class="center">Regisztráció</h1>

        <?php
            // A regisztráció során előforduló esetleges hibák kiíratása.

            if (count($hibak) > 0) {
                echo "<div class='errors'>";

                foreach ($hibak as $hiba) {
                    echo "<p>" . $hiba . "</p>";
                }

                echo "</div>";
            }
        ?>

        <div class="form-container">
            <form action="signup.php" method="POST" autocomplete="off" enctype="multipart/form-data">
                <label for="uname" class="required-label">Felhasználónév: </label>
                <input type="text" name="username" id="uname" required>

                <label for="pswd" class="required-label">Jelszó: </label>
                <input type="password" name="password" id="pswd" required>

                <label for="pswd2" class="required-label">Jelszó ismét: </label>
                <input type="password" name="password2" id="pswd2" required>

                <label for="email" class="required-label">E-mail cím:</label>
                <input type="email" name="email" id="email" required>

                <label for="yob" class="required-label">Születési év:</label>
                <input type="number" name="year-of-birth" id="yob" required>

                <div class="radio-button-container">
                    Nem:
                    <label><input type="radio" name="gender" value="férfi"> Férfi</label>
                    <label><input type="radio" name="gender" value="nő"> Nő</label>
                    <label><input type="radio" name="gender" value="egyéb" checked> Egyéb</label>
                </div>

                <label for="avatar">Profilkép: </label>
                <input type="file" name="profile-picture" id="avatar">

                <div class="checkbox-container">
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="confirm-data" required>
                        Nyilatkozom, hogy a megadott adatok a valóságnak megfelelnek.
                    </label>
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="accept-terms-and-conditions" required>
                        Elfogadom a <a href="https://youtu.be/dQw4w9WgXcQ">felhasználási feltételeket</a>.
                    </label>
                </div>

                <input type="submit" name="signup-btn" value="Regisztráció">
            </form>
        </div>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html><?php
