<header>
    <h1 class="center">Irinyi Pizzázó</h1>
</header>