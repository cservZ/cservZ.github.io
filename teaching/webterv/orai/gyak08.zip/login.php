<?php
    include_once "classes/Felhasznalo.php";
    include_once "common/fuggvenyek.php";

    // Az összes felhasználó betöltése egy tömbbe.
    $felhasznalok = adatokBetoltese("data/felhasznalok.txt");

    // A bejelentkezés sikerességét tároló változó.
    $sikeresBejelentkezes = true;

    // Ellenőrizzük, hogy a belépési adatok helyesek-e! Amennyiben igen, akkor jelentkeztessük be a felhasználót!
    // Amennyiben a bejelentkezési adatok hibásak, akkor állítsuk a $sikeresBejelentkezes változó értékét hamisra!

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Bejelentkezés</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/fuggvenyek.php";

        include_once "common/header.php";
        navigacioGeneralasa("login");
    ?>

    <main>
        <h1 class="center">Bejelentkezés</h1>

        <?php
            // Sikertelen bejelentkezés esetén hibaüzenetet írunk ki.

            if (!$sikeresBejelentkezes) {
                echo "<div class='errors'><p>A belépési adatok nem megfelelők!</p></div>";
            }
        ?>

        <div class="form-container">
            <img src="assets/img/avatar.png" alt="Avatar" class="avatar-icon">
            <form action="login.php" method="POST" autocomplete="off">
                <label for="uname" class="required-label">Felhasználónév: </label>
                <input type="text" name="username" id="uname" required>

                <label for="pswd" class="required-label">Jelszó: </label>
                <input type="password" name="password" id="pswd" required>

                <input type="submit" name="login-btn" value="Bejelentkezés">
            </form>
        </div>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>