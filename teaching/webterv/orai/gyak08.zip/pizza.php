<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Pizzák</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "classes/Pizza.php";
        include_once "common/fuggvenyek.php";

        include_once "common/header.php";
        navigacioGeneralasa("pizza");

        // Beolvassuk a pizzak.txt fájlban található pizzák (Pizza típusú objektumok) adatait egy tömbbe.
        $pizzak = adatokBetoltese("data/pizzak.txt");
    ?>

    <main>
        <h1 class="center">Pizzáink</h1>
        <img src="assets/img/icon.png" alt="Pizza" height="200">

        <table id="pizza-table">
            <tr>
                <th>Pizza neve</th>
                <th>Feltétek</th>
                <th>Ár</th>
                <th>Kosárba tétel</th>
            </tr>
            <?php foreach ($pizzak as $pizza) { ?>
            <tr>
                <td>
                    <b><?php echo $pizza->getNev(); ?></b>
                </td>
                <td>
                    <?php echo implode(", ", $pizza->getFeltetek()); ?>
                </td>
                <td>
                    <?php echo $pizza->getAr() . " Ft"; ?>
                </td>
                <td>
                    <form action="pizza.php" method="GET">
                        <input type="hidden" name="pizza" value="<?php echo $pizza->getNev(); ?>">
                        <input type="submit" value="Kosárba">
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>