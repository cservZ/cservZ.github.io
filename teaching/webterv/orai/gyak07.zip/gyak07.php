<!doctype html>
<html lang="hu">
<head>
    <title>7. gyakorlat</title>
    <meta charset="UTF-8">
</head>
<body>
    <h1>7. gyakorlat</h1>
    <?php
        include "alapok.php";
    ?>
</body>
</html>