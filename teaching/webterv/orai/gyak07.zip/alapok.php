<?php

/*
========================================================================================================================
7. GYAKORLAT - A PHP SZINTAXISA ÉS FONTOSABB NYELVI ELEMEI
========================================================================================================================
*/

// === KIÍRATÁSOK ===

echo "Hello World! <br>";
print "Hello World! <br>";

// === VÁLTOZÓK, KONSTANSOK ===

$pelda1 = "alma";                               // Változó létrehozása
echo "A pelda1 változó értéke: $pelda1 <br>";

define("SEPARATOR", "<hr>");                    // Konstans (állandó) létrehozása

$pelda2 = $pelda1;
$pelda2 = "körte";
echo "A pelda1 változó értéke: $pelda1, a pelda2 változó értéke: $pelda2 <br>";
$pelda1 = "szilva";
echo "A pelda1 változó értéke: $pelda1, a pelda2 változó értéke: $pelda2 <br>";

$pelda = 42;                                    // Gyengén típusosság
$pelda = "macska";

echo SEPARATOR;

// === FONTOSABB ADATTÍPUSOK ===

$logikai = true;
var_dump($logikai); echo "<br>";

$egesz = 42;
var_dump($egesz); echo "<br>";

$lebegopontos = 3.14;
var_dump($lebegopontos); echo "<br>";

$ures = null;
var_dump($ures); echo "<br>";

echo SEPARATOR;

// A string adattípus

$s1 = 'Kecske';
$s2 = "sajt";

$szoveg = $s1 . $s2;                            // Stringösszefűzés
echo "A szövegünk: $szoveg <br>";

echo "A szöveg hossza: " . strlen($szoveg) . "<br>";
echo "A szöveg legelső karaktere: " . $szoveg[0] . "<br>";
echo "A szöveg utolsó karaktere: " . $szoveg[-1] . "<br>";

echo "A szöveg csupa kisbetűkkel: " . strtolower($szoveg) . "<br>";
echo "A szöveg csupa nagybetűkkel: " . strtoupper($szoveg) . "<br>";
echo "A szöveg első 6 karaktere: " . substr($szoveg, 0, 6) . "<br>";
echo "A módosított szöveg (kecske helyett tehén): " . str_replace("Kecske", "Tehén", $szoveg) . "<br>";

$hosszabb_szoveg = "Ez egy hosszabb szöveg";
$szavak = explode(" ", $hosszabb_szoveg);   // Ez egy tömböt ad vissza
print_r($szavak);                                   // Tömbök kiíratására a print_r() függvényt használjuk

echo SEPARATOR;

// A tömb adattípus

$fagyi_izek = ["vanília", "csokoládé", "szamóca", "citrom"];
$arak = ["sült krumpli" => 400, "hamburger" => 800, "diétás kóla" => 300];  // Asszociatív tömb (kulcs-érték párok)

print_r($fagyi_izek); echo "<br>";
print_r($arak); echo "<br>";

echo "A legelső fagyi íz: " . $fagyi_izek[0] . "<br>";
echo "A sült krumpli ára: " . $arak["sült krumpli"] . " forint <br>";       // Adott kulcshoz tartozó érték lekérése

$arak["hamburger"] = 1000;              // Adott kulcshoz tartozó érték módosítása
$arak["sajttorta"] = 400;               // Új kulcs-érték pár beszúrása a tömb végére
$fagyi_izek[] = "sztracsatella";        // Új érték beszúrása a tömb végére

print_r($fagyi_izek); echo "<br>";
print_r($arak); echo "<br>";

echo "A fagyi ízek száma: " . count($fagyi_izek) . "<br>";
echo "A fagyi ízek egy szövegként: " . implode(", ", $fagyi_izek) . "<br>";
echo "Van-e pisztácia a fagyi ízek között? "; var_dump(in_array("pisztácia", $fagyi_izek));

echo SEPARATOR;

// === NÉHÁNY ÉRDEKESEBB OPERÁTOR ===

echo "2^10 = " . (2 ** 10) . "<br>";
echo "5/2 = " . (5 / 2) . "<br>";

var_dump(0 == false); echo "<br>";
var_dump(0 === false); echo "<br>";

echo SEPARATOR;

// === VEZÉRLÉSI SZERKEZETEK ===

// Szelekciós vezérlés (if, else if, else, switch)

$eletkor = 21;

if ($eletkor < 18) {
    echo "Kiskorú vagy <br>";
    echo "Még " . (18 - $eletkor) . " év, és nagykorú leszel <br>";
} else if ($eletkor >= 20 && $eletkor <= 29) {
    echo "Huszonéves vagy <br>";
} else {
    echo "Nagykorú vagy <br>";
}

$erdemjegy = 5;

switch ($erdemjegy) {
    case 1:
        echo "Elégtelen <br>";
        break;
    case 2:
        echo "Elégséges <br>";
        break;
    case 3:
        echo "Közepes <br>";
        break;
    case 4:
        echo "Jó <br>";
        break;
    case 5:
        echo "Jeles <br>";
        break;
    default:
        echo "Érvénytelen érdemjegy! <br>";
}

// Ismétléses vezérlés (Ciklusok)

$i = 1;
while ($i <= 10) {                      // while-ciklus
    echo $i . " ";
    $i++;
}

echo "<br>";

$i = 1;
do {                                    // do...while-ciklus
    echo $i . " ";
    $i++;
} while ($i <= 10);

echo "<br>";

for ($i = 1; $i <= 10; $i++) {          // for-ciklus
    echo $i . " ";
}

echo "<br><br>";

$arak = ["sült krumpli" => 400, "hamburger" => 800, "diétás kóla" => 300];

foreach ($arak as $ar) {
    echo "$ar <br>";
}

// Hogyan lehetne elérni, hogy az alábbi szerkezet ténylegesen megváltoztassa a tömbben lévő árakat?

foreach ($arak as $ar) {
    $ar *= 1.2;
}

print_r($arak);
