<?php
    include_once "classes/Felhasznalo.php";
    include_once "classes/Pizza.php";
    include_once "classes/KosarItem.php";
    include_once "common/fuggvenyek.php";
    session_start();

    // Beolvassuk a pizzak.txt fájlban található pizzák (Pizza típusú objektumok) adatait egy tömbbe.
    $pizzak = adatokBetoltese("data/pizzak.txt");

    // Tegyük működőképessé a kosárba tétel funkciót! Amennyiben egy bejelentkezett felhasználó rákattint egy pizzához
    // tartozó "Kosárba" gombra, akkor tegyük bele az adott pizzát a felhasználó kosarába! A kosárban KosarItem típusú
    // objektumokat tároljuk (minden KosarItem esetén eltároljuk a kosárba tett pizza nevét, az adott pizzából kosárba
    // tett mennyiséget, és a fizetendő árat).

    if (isset($_SESSION["user"]) && isset($_GET["add-to-cart-btn"])) {
        $felhasznalo = $_SESSION["user"];       // A bejelentkezett felhasználó.
        $kosar = $felhasznalo->getKosar();      // A bejelentkezett felhasználó kosara.

        $pizzaNeve = $_GET["pizza-name"];

        foreach ($pizzak as $pizza) {
            if ($pizza->getNev() === $pizzaNeve) {
                $item = new KosarItem($pizza);
                $felhasznalo->kosarbaTesz($item);
            }
        }

        felhasznalokModositasa("data/felhasznalok.txt", $felhasznalo);
        header("Location: pizza.php?siker=true");
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Pizzák</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("pizza");
    ?>

    <main>
        <h1 class="center">Pizzáink</h1>

        <?php
            if (isset($_GET["siker"])) {
                echo "<div class='success'><p>A pizzát sikeresen a kosárba helyezted!</p></div>";
            }
        ?>

        <img src="assets/img/icon.png" alt="Pizza" height="200">

        <table id="pizza-table">
            <tr>
                <th>Pizza neve</th>
                <th>Feltétek</th>
                <th>Ár</th>
                <?php if (isset($_SESSION["user"])) { ?>
                <th>Kosárba tétel</th>
                <?php } ?>
            </tr>
            <?php foreach ($pizzak as $pizza) { ?>
            <tr>
                <td>
                    <b><?php echo $pizza->getNev(); ?></b>
                </td>
                <td>
                    <?php echo implode(", ", $pizza->getFeltetek()); ?>
                </td>
                <td>
                    <?php echo $pizza->getAr() . " Ft"; ?>
                </td>
                <?php if (isset($_SESSION["user"])) { ?>
                <td>
                    <form action="pizza.php" method="GET">
                        <input type="hidden" name="pizza-name" value="<?php echo $pizza->getNev(); ?>">
                        <input type="submit" name="add-to-cart-btn" value="Kosárba">
                    </form>
                </td>
                <?php } ?>
            </tr>
            <?php } ?>
        </table>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>