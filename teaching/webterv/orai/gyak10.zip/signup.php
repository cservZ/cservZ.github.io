<?php
    include_once "classes/Felhasznalo.php";
    include_once "common/fuggvenyek.php";
    session_start();

    // Az összes felhasználó betöltése egy tömbbe.
    $felhasznalok = adatokBetoltese("data/felhasznalok.txt");

    // A regisztráció során keletkező esetleges hibákat ebben a tömbben fogjuk eltárolni.
    $hibak = [];

    // Ha a felhasználó rákattintott a "Regisztráció" gombra, akkor elmentjük a begépelt adatokat egy-egy változóba.
    // (MEGJEGYZÉS: A profilkép feltöltése funkciót majd egy későbbi gyakorlaton fogjuk működőképessé tenni.)

    if (isset($_POST["signup-btn"])) {
        $felhasznalonev = $_POST["username"];
        $jelszo = $_POST["password"];
        $ellenorzoJelszo = $_POST["password2"];
        $email = $_POST["email"];
        $szuletesiEv = $_POST["year-of-birth"];
        $nem = "egyéb";
        $jelolonegyzetek = [];

        // Választógombok és jelölőnégyzetek esetén először érdemes leellenőrizni, hogy egyáltalán bejelölt-e legalább
        // 1 opciót a felhasználó (isset() függvény). Ha nem lett egy opció sem bejelölve, akkor a $_POST tömbben nem
        // lesz "gender" vagy éppen "confirmations" kulcs (ekkor hibát kaphatunk a tömb indexelésekor).

        if (isset($_POST["gender"])) {
            $nem = $_POST["gender"];
        }

        if (isset($_POST["confirmations"])) {
            $jelolonegyzetek = $_POST["confirmations"];
        }

        // Ellenőrizzük, hogy a kötelezően kitöltendő mezők ténylegesen ki lettek-e töltve adattal!

        if (trim($felhasznalonev) === "" || trim($jelszo) === "" || trim($ellenorzoJelszo) === "" ||
            trim($email) === "" || trim($szuletesiEv) === "") {
            $hibak[] = "Minden kötelezően kitöltendő mezőt ki kell tölteni!";
        }

        // Ellenőrizzük, hogy csak olyan felhasználónévvel lehessen regisztrálni, ami még nem foglalt!

        foreach ($felhasznalok as $felhasznalo) {
            if ($felhasznalo->getFelhasznalonev() === $felhasznalonev) {
                $hibak[] = "A felhasználónév már foglalt!";
            }
        }

        // Ellenőrizzük, hogy a felhasználónév értéke ne lehessen a "default" szöveg!

        if ($felhasznalonev === "default") {
            $hibak[] = "A felhasználónév már foglalt!";
        }

        // Ellenőrizzük, hogy a jelszó hossza legalább 5 karakter legyen!

        if (strlen($jelszo) < 5) {
            $hibak[] = "A jelszónak legalább 5 karakter hosszúnak kell lennie!";
        }

        // Érjük el, hogy a jelszónak tartalmaznia kelljen betűt és számjegyet is!

        if (!preg_match("/[A-Za-z]/", $jelszo) || !preg_match("/[0-9]/", $jelszo)) {
            $hibak[] = "A jelszónak tartalmaznia kell betűt és számjegyet is!";
        }

        // Ellenőrizzük, hogy az űrlapon megadott e-mail cím formátuma megfelelő-e!

        if (!preg_match("/[0-9a-z.-]+@([0-9a-z-]+\.)+[a-z]{2,4}/", $email)) {
            $hibak[] = "A megadott e-mail cím formátuma nem megfelelő!";
        }

        // Ellenőrizzük, hogy a jelszó és az ellenőrző jelszó megegyezik-e!

        if ($jelszo !== $ellenorzoJelszo) {
            $hibak[] = "A két jelszó nem egyezik!";
        }

        // Ellenőrizzük, hogy csak olyan e-mail címmel lehessen regisztrálni, ami még nem foglalt!

        foreach ($felhasznalok as $felhasznalo) {
            if ($felhasznalo->getEmail() === $email) {
                $hibak[] = "Az e-mail cím már foglalt!";
            }
        }

        // Valósítsuk meg a profilkép feltöltését a fuggvenyek.php-ban definiált profilkepFeltoltese() függvénnyel!
        profilkepFeltoltese($hibak, $felhasznalonev);

        // Ellenőrizzük, hogy mindkét jelölőnégyzetet bejelölte-e a felhasználó!

        if (count($jelolonegyzetek) < 2) {
            $hibak[] = "Mindkét jelölőnégyzetet be kell jelölni!";
        }

        // Ha az űrlapon megadott adatok helyesek, akkor mentsük el a felhasználó adatait!

        if (count($hibak) === 0) {
            $jelszo = password_hash($jelszo, PASSWORD_DEFAULT);         // Jelszó titkosítása
            $felhasznalo = new Felhasznalo($felhasznalonev, $jelszo, $email, $szuletesiEv, $nem);
            $felhasznalok[] = $felhasznalo;
            adatokMentese("data/felhasznalok.txt", $felhasznalok);    // Felhasználók fájlba való mentése
            header("Location: signup.php?siker=true");
        }
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Regisztráció</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("signup");
    ?>

    <main>
        <h1 class="center">Regisztráció</h1>

        <?php
            if (isset($_GET["siker"])) {
                echo "<div class='success'><p>Sikeres regisztráció!</p></div>";
            }

            // A regisztráció során előforduló esetleges hibák kiíratása.

            if (count($hibak) > 0) {
                echo "<div class='errors'>";

                foreach ($hibak as $hiba) {
                    echo "<p>" . $hiba . "</p>";
                }

                echo "</div>";
            }
        ?>

        <div class="form-container">
            <form action="signup.php" method="POST" autocomplete="off" enctype="multipart/form-data">
                <label for="uname" class="required-label">Felhasználónév: </label>
                <input type="text" name="username" id="uname" required
                    <?php if (isset($_POST["username"])) echo "value='" . $_POST["username"] . "'" ?>>

                <label for="pswd" class="required-label">Jelszó: </label>
                <input type="password" name="password" id="pswd" required>

                <label for="pswd2" class="required-label">Jelszó ismét: </label>
                <input type="password" name="password2" id="pswd2" required>

                <label for="email" class="required-label">E-mail cím:</label>
                <input type="email" name="email" id="email" required
                    <?php if (isset($_POST["email"])) echo "value='" . $_POST["email"] . "'" ?>>

                <label for="yob" class="required-label">Születési év:</label>
                <input type="number" name="year-of-birth" id="yob" required
                    <?php if (isset($_POST["year-of-birth"])) echo "value='" . $_POST["year-of-birth"] . "'" ?>>

                <div class="radio-button-container">
                    Nem:
                    <label>
                        <input type="radio" name="gender" value="férfi"
                            <?php if (isset($_POST["gender"]) && $_POST["gender"] === "férfi") echo "checked"; ?>>
                        Férfi
                    </label>
                    <label>
                        <input type="radio" name="gender" value="nő"
                            <?php if (isset($_POST["gender"]) && $_POST["gender"] === "nő") echo "checked"; ?>>
                        Nő
                    </label>
                    <label>
                        <input type="radio" name="gender" value="egyéb"
                            <?php if (!isset($_POST["gender"]) || $_POST["gender"] === "egyéb") echo "checked"; ?>>
                        Egyéb
                    </label>
                </div>

                <label for="avatar">Profilkép: </label>
                <input type="file" name="profile-picture" id="avatar">

                <div class="checkbox-container">
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="confirm-data" required>
                        Nyilatkozom, hogy a megadott adatok a valóságnak megfelelnek.
                    </label>
                    <label class="required-label">
                        <input type="checkbox" name="confirmations[]" value="accept-terms-and-conditions" required>
                        Elfogadom a <a href="https://youtu.be/dQw4w9WgXcQ">felhasználási feltételeket</a>.
                    </label>
                </div>

                <input type="submit" name="signup-btn" value="Regisztráció">
            </form>
        </div>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html><?php
