<footer>
    <p class="center">&copy; Irinyi Pizzázó</p>
</footer>