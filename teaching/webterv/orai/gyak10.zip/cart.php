<?php
    include_once "classes/Felhasznalo.php";
    include_once "classes/Pizza.php";
    include_once "classes/KosarItem.php";
    include_once "classes/Rendeles.php";
    include_once "common/fuggvenyek.php";
    session_start();

    // Ha a felhasználó nincs bejelentkezve, akkor átirányítjuk a bejelentkezés oldalra.

    if (!isset($_SESSION["user"])) {
        header("Location: login.php");
    }

    // A bejelentkezett felhasználó lementése egy változóba.
    $felhasznalo = $_SESSION["user"];

    // A bejelentkezett felhasználó kosarának lementése egy változóba.
    $kosar = $felhasznalo->getKosar();

    // Valósítsuk meg egy megadott kosárbeli termék törlését! Ha a felhasználó a "Törlés" gombra kattint, akkor töröljük
    // ki a felhasználó kosarából az összes, adott névvel rendelkező pizzát!

    if (isset($_GET["delete-from-cart-btn"])) {
        // TODO

         // felhasznalokModositasa("data/felhasznalok.txt", $felhasznalo);
         // header("Location: cart.php");
    }

    // Tegyük működőképessé a "Rendelés" gombot! Ha a felhasználó erre a gombra kattint, akkor hozzunk létre egy új
    // Rendeles típusú objektumot, amelyet inicializáljunk a rendelést leadó felhasználó nevével és ezen felhasználó
    // kosarának tartalmával! A létrehozott rendelést mentsük el a data/rendelesek.txt állományba! Miután a rendelés
    // elmentése megtörtént, ürítsük ki a bejelentkezett felhasználó kosarát!

    if (isset($_GET["order-btn"])) {
        // Az összes rendelés adatainak betöltése (egy Rendeles típusú objektumokat tároló tömbbe).
        $rendelesek = adatokBetoltese("data/rendelesek.txt");

        // TODO


        // felhasznalokModositasa("data/felhasznalok.txt", $felhasznalo);
        // header("Location: cart.php?siker=true");
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Kosaram</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("cart");
    ?>

    <main>
        <h1 class="center">Kosaram</h1>

        <?php
            if (isset($_GET["siker"])) {
                echo "<div class='success'><p>Sikeres rendelés!</p></div>";
            }
        ?>

        <?php if (count($kosar) > 0) { ?>
            <table id="cart-table">
                <tr>
                    <th>Pizza neve</th>
                    <th>Mennyiség</th>
                    <th>Ár</th>
                    <th>Törlés</th>
                </tr>
                <?php foreach ($kosar as $item) { ?>
                <tr>
                    <td><?php echo $item->getNev(); ?></td>
                    <td><?php echo $item->getMennyiseg(); ?></td>
                    <td><?php echo $item->getAr() . " Ft"; ?></td>
                    <td>
                        <form action="cart.php" method="GET" class="cart-delete-form">
                            <input type="hidden" name="item-name" value="<?php echo $item->getNev(); ?>">
                            <input type="submit" name="delete-from-cart-btn" value="Törlés">
                        </form>
                    </td>
                </tr>
                <?php } ?>
                <tr class="total-sum">
                    <th colspan="4">Végösszeg: <?php echo vegosszeg($kosar) ?> Ft</th>
                </tr>
            </table>

            <form action="cart.php" method="GET" class="order-form">
                <input type="submit" name="order-btn" value="Rendelés">
            </form>
        <?php } else { ?>
            <p class="center strong">A kosarad jelenleg üres!</p>
        <?php } ?>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>