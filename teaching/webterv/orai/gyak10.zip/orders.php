<?php
    include_once "classes/Felhasznalo.php";
    include_once "classes/KosarItem.php";
    include_once "classes/Rendeles.php";
    include_once "common/fuggvenyek.php";
    session_start();

    // Az oldalt csak az admin felhasználó számára tesszük elérhetővé.

    if (!isset($_SESSION["user"])) {
        header("Location: login.php");
    }

    if ($_SESSION["user"]->getFelhasznalonev() !== "admin") {
        header("Location: index.php");
    }

    // Az összes rendelés adatainak betöltése (egy Rendeles típusú objektumokat tároló tömbbe).
    $rendelesek = adatokBetoltese("data/rendelesek.txt");

    // A rendelések szétosztása nem teljesített és teljesített rendelések kategóriákba.

    $nemTeljesitettRendelesek = [];
    $teljesitettRendelesek = [];

    foreach ($rendelesek as $rendeles) {
        if ($rendeles->isTeljesitett()) {
            $teljesitettRendelesek[] = $rendeles;
        } else {
            $nemTeljesitettRendelesek[] = $rendeles;
        }
    }

    // Amennyiben az admin felhasználó rányom a "Teljesítés" gombra, akkor állítsuk a megfelelő Rendeles objektum
    // $teljesitett adattagját igazra, és töltsük újra az oldalt!

    if (isset($_GET["complete-order-btn"])) {
        $megrendelo = $_GET["orderer"];
        $rendelesDatuma = $_GET["order-date"];

        foreach ($rendelesek as &$rendeles) {
            if ($rendeles->getMegrendelo() === $megrendelo &&
                $rendeles->getRendelesDatuma()->format("Y-m-d H:i:s") === $rendelesDatuma) {
                $rendeles->setTeljesitett(true);
            }
        }

        adatokMentese("data/rendelesek.txt", $rendelesek);
        header("Location: orders.php");
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <title>Rendelések</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets/img/icon.png">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php
        include_once "common/header.php";
        navigacioGeneralasa("orders");
    ?>

    <main>
        <h1 class="center">Rendelések</h1>

        <?php if (count($rendelesek) > 0) { ?>
            <?php if (count($nemTeljesitettRendelesek) > 0) { ?>
                <h2 class="center">Aktív (nem teljesített) rendelések</h2>
                <table>
                    <tr>
                        <th>Rendelést feladó felhasználó</th>
                        <th>Rendelés dátuma</th>
                        <th>Rendelés tartalma</th>
                        <th></th>
                    </tr>
                    <?php foreach ($nemTeljesitettRendelesek as $rendeles) { ?>
                    <tr>
                        <td><?php echo $rendeles->getMegrendelo(); ?></td>
                        <td><?php echo $rendeles->getRendelesDatuma()->format("Y-m-d H:i:s"); ?></td>
                        <td><?php echo implode("<br>", $rendeles->getRendelesTartalma()); ?></td>
                        <td>
                            <form action="orders.php" method="GET" class="complete-order-form">
                                <input type="hidden" name="orderer"
                                       value="<?php echo $rendeles->getMegrendelo(); ?>">
                                <input type="hidden" name="order-date"
                                       value="<?php echo $rendeles->getRendelesDatuma()->format('Y-m-d H:i:s'); ?>">
                                <input type="submit" name="complete-order-btn" value="Teljesítés">
                            </form>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
            <?php } ?>

            <?php if (count($teljesitettRendelesek) > 0) { ?>
                <hr>
                <h2 class="center">Teljesített rendelések</h2>
                <table>
                    <tr>
                        <th>Rendelést feladó felhasználó</th>
                        <th>Rendelés dátuma</th>
                        <th>Rendelés tartalma</th>
                    </tr>
                    <?php foreach ($teljesitettRendelesek as $rendeles) { ?>
                        <tr>
                            <td><?php echo $rendeles->getMegrendelo(); ?></td>
                            <td><?php echo $rendeles->getRendelesDatuma()->format("Y-m-d H:i:s"); ?></td>
                            <td><?php echo implode("<br>", $rendeles->getRendelesTartalma()); ?></td>
                        </tr>
                    <?php } ?>
                </table>
            <?php } ?>
        <?php } else { ?>
            <p class="center strong">Még egyetlen rendelés sem érkezett!</p>
        <?php } ?>
    </main>

    <?php
        include_once "common/footer.php";
    ?>
</body>
</html>