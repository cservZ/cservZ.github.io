<?php

class KosarItem {
    private string $nev;
    private int $mennyiseg;
    private int $ar;

    // Konstruktor

    public function __construct(Pizza $pizza, int $mennyiseg=1) {
        $this->nev = $pizza->getNev();
        $this->mennyiseg = $mennyiseg;
        $this->ar = $this->mennyiseg * $pizza->getAr();
    }

    // Getterek és setterek

    public function getNev(): string {
        return $this->nev;
    }

    public function setNev(string $nev): void {
        $this->nev = $nev;
    }

    public function getMennyiseg(): int {
        return $this->mennyiseg;
    }

    public function setMennyiseg(int $mennyiseg): void {
        $this->mennyiseg = $mennyiseg;
    }

    public function getAr(): int {
        return $this->ar;
    }

    public function setAr(int $ar): void {
        $this->ar = $ar;
    }

    // Az objektum szöveggé alakításáért felelő metódus

    public function __toString(): string {
        return $this->mennyiseg . " " . strtolower($this->nev) . " (" . $this->ar . " Ft)";
    }
}